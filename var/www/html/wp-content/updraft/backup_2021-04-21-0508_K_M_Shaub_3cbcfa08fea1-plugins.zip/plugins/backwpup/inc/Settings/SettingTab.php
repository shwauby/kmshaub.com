<?php # -*- coding: utf-8 -*-

namespace Inpsyde\BackWPup\Settings;

/**
 * Class SettingTab
 */
interface SettingTab {

	public function tab();
}
